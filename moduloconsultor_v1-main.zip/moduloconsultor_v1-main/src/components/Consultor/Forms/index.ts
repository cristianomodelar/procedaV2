// web/src/components/Consultor/Forms/index.ts
export { default as ModalWrapper } from './ModalWrapper';
export { default as CadeiaValorForm } from './CadeiaValorForm';
export { default as AtributosProcessoForm } from './AtributosProcessoForm';
